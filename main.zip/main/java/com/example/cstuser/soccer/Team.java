package com.example.cstuser.soccer;

/**
 * Created by baoqiyu on 4/13/2016.
 */
public class Team {
    public String id,name,city,country;
    public Team(String id,String name,String city,String contry){
        this.country=contry;
        this.city=city;
        this.id=id;
        this.name=name;
    }
}
