package com.example.cstuser.soccer;

public interface constants {

    // constants for slideshow and exit button
    int lAST_IMAGE = 4;
    int FIRST_IMAGE = 0;
    int DELAY = 2000;
    int PERIOD = 5000;
    String[] CAPTIONS = {"Main Building from St-Croix street", "Main building on a cloudy day", "Main building (close-up)", "Happy Vanier students", "Cafeteria in N building"};
    Integer[] IMAGE_IDS = {R.drawable.pic1, R.drawable.pic2, R.drawable.pic3, R.drawable.pic4,R.drawable.pic5};
    String VANIER_WEBSITE = "http://www.vaniercollege.qc.ca/";
    String MELANCHOLIC_MESSAGE = "I'm sorry that you chose to exit :(\nplease come back another time!!!";


    int INITIAL_NOTIFICATION_ID = 1;
    String NOTIFICATION_MESSAGE = "Notification Sent";
    String SMS_MESSAGE_SENT = "You message has been sent";
    String INVALID_CONTACT ="Invalid Contact";
    String ANTHONY_FUNICIELLO = "Anthony Funiciello";
    String KEVING_TSAI= "Kevin Tsai";
    String TIMOTHY_RODRIGUEZ = "Timothy Rodriguez";
    String JOSH_PHAM = "Josh Pham";
    String MAYURRAN_SELLIAH = "Mayurran Selliah";
    String BAOQI_YU = "Baoqi Yu";
    String DAVID_LIU = "David Liu";
    String JASON_TIU = "Jason Tiu";
    String SHERIFF_GHAFFAR = "Sheriff Ghaffar";
    String DANIEL_EDERY = "Daniel Edery";
    String PHONENUMBER1 = "5143156428";
    String PHONENUMBER2 = "5146432157";
    String PHONENUMBER3 = "5142469157";
    String PHONENUMBER4 = "5142389475";






}
