package com.example.cstuser.soccer;

import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


public class SMS extends Activity implements constants {

    private Spinner contactList;
    String phoneNumber;
    private Button sendSMS, sendNotif, returnMenuBtn;
    int notificationID;
    String[] contactsArray;

    public SMS() {
        this.notificationID = INITIAL_NOTIFICATION_ID;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_main);

        addItemsOnContactsList();


        sendSMS = (Button) findViewById(R.id.btnSendSMS);
        sendNotif = (Button) findViewById(R.id.btnNotif);
        returnMenuBtn = (Button) findViewById(R.id.returnMenuBtn);

        sendSMS.setOnClickListener(listener);
        sendNotif.setOnClickListener(listener);
        returnMenuBtn.setOnClickListener(listener);

    }


    private void sendSMS(String phoneNumber, String message) {
        SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
    }

    protected void displayNotification() {
        Intent i = new Intent(this, Notification.class);
        i.putExtra("notificationID", this.notificationID);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, i, 0);
        NotificationManager nm =  (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        Notification notif = new Notification(R.mipmap.ic_launcher, NOTIFICATION_MESSAGE, System.currentTimeMillis());
        notif.setLatestEventInfo(this, contactList.getSelectedItem().toString(), SMS_MESSAGE_SENT, pendingIntent);
        notif.vibrate = new long[]{100, 250, 100, 500};
        nm.notify(this.notificationID, notif);
    }




    // add items into spinner dynamically
    public void addItemsOnContactsList() {

        contactList = (Spinner) findViewById(R.id.contactSpinner);
        contactsArray = getResources().getStringArray(R.array.contacts_array);

        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, contactsArray);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        contactList.setAdapter(dataAdapter);
    }

    private View.OnClickListener listener = new View.OnClickListener() {
        public void onClick(View v) {
            if(v == sendSMS){
                switch (contactList.getSelectedItem().toString()){

                    case ANTHONY_FUNICIELLO: phoneNumber = PHONENUMBER1; break;
                    case KEVING_TSAI: phoneNumber = PHONENUMBER2; break;
                    case TIMOTHY_RODRIGUEZ: phoneNumber = PHONENUMBER3; break;
                    case JOSH_PHAM:phoneNumber = PHONENUMBER4; break;
                    case MAYURRAN_SELLIAH: phoneNumber = PHONENUMBER3; break;
                    case BAOQI_YU: phoneNumber = PHONENUMBER4; break;
                    case DAVID_LIU:phoneNumber = PHONENUMBER1; break;
                    case JASON_TIU:phoneNumber = PHONENUMBER2; break;
                    case SHERIFF_GHAFFAR: phoneNumber = PHONENUMBER4; break;
                    case DANIEL_EDERY: phoneNumber = PHONENUMBER2; break;
                    default: phoneNumber = INVALID_CONTACT; break;

                }
                sendSMS(phoneNumber, "Hello my friends!");

            }else if(v == sendNotif){
                displayNotification();
            }
            else if(v == returnMenuBtn){
               finish();
            }
        }
    };



}
