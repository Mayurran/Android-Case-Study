package com.example.cstuser.soccer;

/**
 * Created by baoqiyu on 4/13/2016.
 */
public class Player {
    public String name,id,birthDate,salary,teamid;
    public Player(String id,String name,String birth,String salary,String teamid){
        this.name=name;
        this.id=id;
        this.birthDate=birth;
        this.salary=salary;
        this.teamid=teamid;
    }
}
